# Tron Miner

## Overview

Tron Miner is a single-page cryptocurrency mining simulator built as a client-side demonstration application. It features a Telegram-inspired interface where users can simulate TRX (Tron) mining with advanced cooling systems, Air Flow technology, and real-time temperature management. **Important: All TRX transactions and mining operations are simulated - there is no blockchain connection.** The application uses localStorage for data persistence and provides an engaging gamified mining experience with visual feedback through animated fan graphics and color-coded temperature indicators.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework & Tooling:**
- **React 18** with TypeScript for type-safe component development
- **Vite** as the build tool and development server
- **Wouter** for lightweight client-side routing
- **TanStack Query (React Query)** for server state management (currently minimal backend interaction)

**UI Component System:**
- **shadcn/ui** component library based on Radix UI primitives
- Custom Tailwind CSS configuration with dark-mode-optimized cryptocurrency theme
- CSS variables for dynamic theming (cyan/neon accent colors, temperature-based color states)
- Responsive design with mobile-first approach

**State Management:**
- Local component state using React hooks (`useState`, `useEffect`)
- localStorage for persistent game state across sessions
- Custom types defined in `shared/types.ts` for type safety

**Design Philosophy:**
The UI follows Telegram's @BotFather interface aesthetic - clean, centered, minimal with rounded buttons, soft shadows, and subtle glows. The design prioritizes simplicity and smooth animations over heavy graphics.

### Backend Architecture

**Server Setup:**
- **Express.js** server configured but minimal implementation
- Prepared for future API routes (routes defined in `server/routes.ts`)
- Development and production build scripts configured

**Data Storage:**
- **In-Memory Storage** implementation (`MemStorage` class in `server/storage.ts`)
- Interface-based design allows swapping to database later
- Currently stores user data structure (id, username, password)
- **Note:** Actual mining data is client-side only via localStorage

**Database Schema (Prepared but Not Active):**
- **Drizzle ORM** configured for PostgreSQL
- Schema defined in `shared/schema.ts` with users table
- Drizzle Kit configured for migrations
- Database connection ready via `@neondatabase/serverless`

The application currently operates entirely client-side. The backend infrastructure is scaffolded for future expansion but mining simulation runs locally in the browser.

### External Dependencies

**UI & Components:**
- **Radix UI** - Comprehensive set of accessible, unstyled UI primitives (dialogs, tooltips, buttons, etc.)
- **Tailwind CSS** - Utility-first CSS framework with custom configuration
- **Lucide React** - Icon library for UI elements (Fan, Wallet, Power icons, etc.)
- **class-variance-authority** - Utility for managing component variants
- **clsx** & **tailwind-merge** - Class name merging utilities

**Forms & Validation:**
- **React Hook Form** - Form state management (prepared for future use)
- **Zod** - Schema validation library
- **@hookform/resolvers** - Integrates Zod with React Hook Form

**Database (Configured):**
- **Drizzle ORM** - TypeScript ORM for database operations
- **@neondatabase/serverless** - Serverless PostgreSQL driver
- **drizzle-zod** - Zod schema generation from Drizzle schemas

**Development Tools:**
- **Replit plugins** - Custom Vite plugins for Replit environment (cartographer, dev banner, runtime error overlay)
- **TypeScript** - Static type checking
- **ESBuild** - Fast JavaScript bundler for production builds

**Assets:**
- Custom fan image located at `attached_assets/fan_1760842981113.png`
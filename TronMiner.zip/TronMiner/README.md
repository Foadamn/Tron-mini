# Tron Miner

A beautiful single-page cryptocurrency mining simulator with a clean, Telegram-inspired interface. Mine TRX with advanced cooling systems, Air Flow technology, and real-time temperature management.

> **Note:** This is a client-side demonstration application. All TRX transactions and mining operations are **simulated** (no blockchain connection).

## Features

- 🌀 **Animated Mining Fan** - Rotates when active, spins faster with Air Flow
- ⚡ **Power Management** - 3 TRX activates 3-hour mining sessions
- 💨 **Air Flow Upgrade** - 1 TRX extends runtime to 6 hours and triples mining rate
- 🌡️ **Temperature System** - Real-time monitoring with color-coded warnings
- 💰 **Wallet Management** - Track balance and mined TRX
- 💾 **Auto-Save** - All progress automatically saved to localStorage
- 📱 **Responsive Design** - Works beautifully on desktop and mobile

## How to Use

### 1. Get Started
1. Open the application
2. Click the **Wallet** icon in the bottom navigation
3. Click **"+ Add 10 TRX (Test)"** to add simulated balance

### 2. Activate Mining
1. Click the **Payment** icon in the bottom navigation
2. Click **"Activate Power (3 TRX)"** to start a 3-hour mining session
3. Click the **Power** button to turn ON the miner
4. Watch the fan spin and your TRX balance grow!

### 3. Upgrade with Air Flow (Optional)
1. While mining is active, open the **Payment** modal
2. Click **"Activate Air Flow (1 TRX)"** to:
   - Extend session to 6 hours
   - Triple mining rate (1 TRX/hour → 3 TRX/hour)
   - Add a cool blue glow effect to the fan

### 4. Monitor Temperature
- Temperature rises gradually from 30°C to 100°C
- Color indicators:
  - 🟢 **Green** (<60°C) - Optimal
  - 🟡 **Yellow** (60-85°C) - Warm
  - 🔴 **Red** (85°C+) - Hot
- At ~90-100°C, the miner will overheat and stop
- Air Flow slows temperature rise for longer sessions

## Mining Rates

| Mode | Rate | Session Duration |
|------|------|------------------|
| Base | 1 TRX/hour | 3 hours |
| With Air Flow | 3 TRX/hour | 6 hours |

## Costs

- **Power Activation**: 3 TRX (enables 3-hour session)
- **Air Flow Upgrade**: 1 TRX (extends to 6 hours, 3x mining rate)

## Replacing the Fan Icon

The fan icon is located at `attached_assets/fan_1760842981113.png`. To replace it:

1. Add your custom fan image to the `attached_assets/` folder
2. Update the import in `client/src/pages/tron-miner.tsx`:
   ```typescript
   import fanImage from '@assets/your-fan-image.png';
   ```

## Technical Details

### Stack
- **Frontend**: React + TypeScript + Vite
- **Styling**: Tailwind CSS + Custom animations
- **UI Components**: shadcn/ui
- **State Management**: React hooks + localStorage
- **No Backend**: Fully client-side application

### File Structure
```
├── client/
│   ├── src/
│   │   ├── pages/
│   │   │   └── tron-miner.tsx    # Main application component
│   │   └── index.css             # Tron theme + animations
│   └── index.html                # SEO and metadata
├── shared/
│   └── types.ts                  # TypeScript interfaces
├── attached_assets/
│   └── fan_1760842981113.png     # Fan icon
└── README.md
```

### localStorage Keys
- `tron_miner_state` - Stores wallet balance, mining state, temperature, and session data

### Simulated Features
All cryptocurrency operations are simulated:
- ✅ Wallet balance (no real TRX)
- ✅ Mining rewards (calculated client-side)
- ✅ Payments (deducted from simulated balance)
- ❌ No blockchain connection
- ❌ No real cryptocurrency transactions

## Development

### Running Locally
```bash
npm install
npm run dev
```

The app will start on `http://localhost:5000`

### Testing Scenarios

**Scenario 1: Basic Mining**
1. Add 10 TRX test balance
2. Pay 3 TRX to activate power
3. Turn power ON
4. Watch mining progress for 30 seconds
5. Verify TRX increases and temperature rises

**Scenario 2: Air Flow Upgrade**
1. Complete Scenario 1
2. Pay 1 TRX for Air Flow
3. Observe faster fan rotation and blue glow
4. Verify mining rate increases (3x faster)

**Scenario 3: Overheat**
1. Fast-forward by setting temperature high in browser dev tools
2. Observe automatic shutdown at overheat threshold
3. Verify need to pay 3 TRX to restart

**Scenario 4: localStorage Persistence**
1. Start mining
2. Refresh page
3. Verify state is restored (balance, mining status, temperature)

### Clean State
To reset the application:
1. Open browser Developer Tools (F12)
2. Go to Application > Local Storage
3. Delete `tron_miner_state` key
4. Refresh page

## Credits

Built with modern web technologies and inspired by Telegram's @BotFather interface for a clean, minimal aesthetic.

## License

This is a demonstration project. Feel free to use and modify as needed.

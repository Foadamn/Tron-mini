# Tron Miner - Design Guidelines

## Design Approach
**Reference-Based Approach**: Telegram @BotFather Interface
- Clean, centered, minimal aesthetic
- Modern rounded buttons with soft shadows and subtle glows
- Clear typography with generous spacing
- No clutter, focus on simplicity and smooth animations
- Balanced modern look that feels native to Telegram mini apps

## Core Design Elements

### A. Color Palette

**Background**
- Smooth gradient from black (#000) to dark gray (#222)

**Accent Colors**
- Neon cyan for glows and highlights
- Neon green for active states
- Blue glow for Air Flow feature

**Temperature States**
- Green: <60°C
- Yellow: 60-85°C
- Red: 85°C+

### B. Typography
- Clear, balanced modern typeface
- Generous spacing between elements
- Clean hierarchy for readability on both desktop and mobile

### C. Layout System

**Primary Spacing**
- Centered vertically and horizontally
- Generous spacing between all elements
- No unnecessary borders or heavy graphics

**Component Arrangement** (Top to Bottom)
1. Large centered fan icon
2. Power button (rectangular, large, rounded corners)
3. Air Flow button (small square, left of Power button)
4. Temperature button (rectangular, below Power and Air Flow)
5. Mined TRX counter
6. Fixed bottom navigation bar (three evenly spaced icons)

### D. Component Specifications

**Fan Icon**
- Large, centered placeholder (to be replaced with uploaded asset: fan_1760842981113.png)
- Rotates when ON
- Spins faster with blue glow when Air Flow active
- Subtle wind particles during Air Flow state

**Power Button**
- Rectangular, large size
- Rounded corners
- Green glow when ON
- Inactive state when not paid
- Smooth transition animations

**Air Flow Button**
- Small square button
- Positioned to the left of Power button
- Subtle blue glow when active
- Only available after initial payment

**Temperature Button**
- Rectangular shape
- Displays "TEMP: [number]°C"
- Dynamic color transitions (green → yellow → red)
- Updates in real-time

**Mined TRX Display**
- Format: "Mined TRX: [number]"
- Smooth incremental animations
- Clear, prominent typography

**Bottom Navigation Bar**
- Fixed position
- Three evenly spaced icons:
  - Fan icon (general status)
  - Wallet icon (opens wallet modal)
  - Payment icon (opens payment modal)
- Simple, minimal design
- Glowing effects on hover/active
- White or cyan icon colors

**Modals**
- Wallet modal: Shows TRX balance, "+ Add 10 TRX" button
- Payment modal: Success/failure messages ("Insufficient balance")
- Clean overlay design matching main interface aesthetic

### E. Visual Effects & Animations

**Glows & Shadows**
- Soft shadows on all interactive elements
- Neon cyan/green glows for active states
- Blue glow for Air Flow feature
- Subtle outer glow on buttons

**Animations**
- Fan rotation (smooth, continuous)
- Faster rotation during Air Flow
- Smooth TRX counter increments (small steps every few seconds)
- Temperature color transitions
- Button state changes (gentle fades)
- Wind particle effects (subtle, not distracting)

**Interactive States**
- Hover effects on navigation icons
- Active state glows
- Disabled state for unpaid features

### F. Responsive Design
- Works beautifully on both desktop and mobile
- Centered layout adapts to viewport
- Touch-friendly button sizes on mobile
- Maintains visual hierarchy across devices

## Images
**Fan Icon**: Use provided asset (fan_1760842981113.png) as the main rotating fan element. This is a central visual element, not a hero image. The entire interface is a centered interactive application without traditional hero sections.
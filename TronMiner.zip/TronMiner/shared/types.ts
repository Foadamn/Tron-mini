/**
 * Tron Miner App State Types
 * All mining and payment functionality is SIMULATED (no blockchain connection)
 */

export interface MinerState {
  // Wallet balance (simulated TRX)
  balance: number;
  
  // Mining session state
  isPowerOn: boolean;
  isAirFlowActive: boolean;
  
  // Time management
  sessionStartTime: number | null; // timestamp when session started
  totalSessionDuration: number; // in milliseconds (3h or 6h)
  
  // Mining metrics
  minedTRX: number;
  currentTemperature: number; // in Celsius (30-100)
  
  // Feature unlocks
  hasPaidForPower: boolean; // paid 3 TRX for initial power
  
  // Timestamps for calculation
  lastUpdateTime: number;
}

export interface StorageKeys {
  MINER_STATE: 'tron_miner_state';
}

export const STORAGE_KEY: StorageKeys['MINER_STATE'] = 'tron_miner_state';

// Constants for game mechanics
export const CONSTANTS = {
  POWER_COST: 3, // TRX cost to start mining
  AIRFLOW_COST: 1, // TRX cost for Air Flow upgrade
  
  BASE_SESSION_DURATION: 3 * 60 * 60 * 1000, // 3 hours in ms
  AIRFLOW_SESSION_DURATION: 6 * 60 * 60 * 1000, // 6 hours in ms
  
  BASE_MINING_RATE: 1, // 1 TRX per hour
  AIRFLOW_MINING_RATE: 3, // 3 TRX per hour with Air Flow
  
  MIN_TEMPERATURE: 30, // Starting temperature
  MAX_TEMPERATURE: 100, // Overheat threshold
  OVERHEAT_THRESHOLD: 90, // When to stop mining
  
  TEST_BALANCE_ADD: 10, // Amount to add when testing
} as const;

// Temperature color states
export type TemperatureState = 'green' | 'yellow' | 'red';

export function getTemperatureState(temp: number): TemperatureState {
  if (temp < 60) return 'green';
  if (temp < 85) return 'yellow';
  return 'red';
}

// Initial state
export const INITIAL_MINER_STATE: MinerState = {
  balance: 0,
  isPowerOn: false,
  isAirFlowActive: false,
  sessionStartTime: null,
  totalSessionDuration: 0,
  minedTRX: 0,
  currentTemperature: CONSTANTS.MIN_TEMPERATURE,
  hasPaidForPower: false,
  lastUpdateTime: Date.now(),
};

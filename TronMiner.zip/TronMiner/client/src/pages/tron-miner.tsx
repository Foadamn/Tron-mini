import { useState, useEffect, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Fan, Wallet, CreditCard, Wind, Power, Thermometer } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import {
  MinerState,
  INITIAL_MINER_STATE,
  STORAGE_KEY,
  CONSTANTS,
  getTemperatureState,
} from '@shared/types';
import fanImage from '@assets/fan_1760842981113.png';

/**
 * Tron Miner - Cryptocurrency Mining Simulator
 * NOTE: All TRX transactions and mining are SIMULATED (no blockchain connection)
 * This is a client-side demo application for educational purposes
 */

export default function TronMiner() {
  const { toast } = useToast();
  const [state, setState] = useState<MinerState>(INITIAL_MINER_STATE);
  const [walletOpen, setWalletOpen] = useState(false);
  const [paymentOpen, setPaymentOpen] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState<string>('0:00:00');

  // Load state from localStorage on mount
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved) as MinerState;
        setState(parsed);
      } catch (e) {
        console.error('Failed to parse saved state:', e);
      }
    }
  }, []);

  // Save state to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }, [state]);

  // Main game loop - updates mining, temperature, and timer
  useEffect(() => {
    if (!state.isPowerOn || !state.sessionStartTime) {
      return;
    }

    const interval = setInterval(() => {
      const now = Date.now();
      const elapsed = now - state.sessionStartTime!;
      const timeSinceLastUpdate = now - state.lastUpdateTime;
      
      // Check if session has ended
      if (elapsed >= state.totalSessionDuration) {
        setState(prev => ({
          ...prev,
          isPowerOn: false,
          hasPaidForPower: false,
          isAirFlowActive: false,
          totalSessionDuration: 0,
          currentTemperature: CONSTANTS.MIN_TEMPERATURE,
          lastUpdateTime: now,
        }));
        toast({
          title: 'Session Ended',
          description: 'Your mining session has completed. Pay 3 TRX to restart.',
        });
        return;
      }

      // Calculate temperature increase (slower with Air Flow)
      const tempIncreaseRate = state.isAirFlowActive 
        ? (CONSTANTS.MAX_TEMPERATURE - CONSTANTS.MIN_TEMPERATURE) / (CONSTANTS.AIRFLOW_SESSION_DURATION / 1000)
        : (CONSTANTS.MAX_TEMPERATURE - CONSTANTS.MIN_TEMPERATURE) / (CONSTANTS.BASE_SESSION_DURATION / 1000);
      
      const newTemp = Math.min(
        CONSTANTS.MAX_TEMPERATURE,
        state.currentTemperature + (tempIncreaseRate * (timeSinceLastUpdate / 1000))
      );

      // Check for overheat
      if (newTemp >= CONSTANTS.OVERHEAT_THRESHOLD) {
        setState(prev => ({
          ...prev,
          isPowerOn: false,
          hasPaidForPower: false,
          isAirFlowActive: false,
          totalSessionDuration: 0,
          currentTemperature: CONSTANTS.MAX_TEMPERATURE,
          lastUpdateTime: now,
        }));
        toast({
          variant: 'destructive',
          title: 'Overheated!',
          description: 'Your miner has overheated. Pay 3 TRX to restart after cooling.',
        });
        return;
      }

      // Calculate mining rewards
      const miningRate = state.isAirFlowActive 
        ? CONSTANTS.AIRFLOW_MINING_RATE 
        : CONSTANTS.BASE_MINING_RATE;
      
      const trxPerMs = miningRate / (60 * 60 * 1000); // TRX per millisecond
      const minedAmount = trxPerMs * timeSinceLastUpdate;

      setState(prev => ({
        ...prev,
        minedTRX: prev.minedTRX + minedAmount,
        currentTemperature: newTemp,
        lastUpdateTime: now,
      }));

      // Update countdown timer
      const remaining = state.totalSessionDuration - elapsed;
      const hours = Math.floor(remaining / (60 * 60 * 1000));
      const minutes = Math.floor((remaining % (60 * 60 * 1000)) / (60 * 1000));
      const seconds = Math.floor((remaining % (60 * 1000)) / 1000);
      setTimeRemaining(`${hours}:${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`);
    }, 100); // Update every 100ms for smooth animations

    return () => clearInterval(interval);
  }, [state.isPowerOn, state.sessionStartTime, state.isAirFlowActive, state.totalSessionDuration, state.lastUpdateTime, state.currentTemperature, toast]);

  // Add test balance (simulated)
  const addTestBalance = useCallback(() => {
    setState(prev => ({
      ...prev,
      balance: prev.balance + CONSTANTS.TEST_BALANCE_ADD,
    }));
    toast({
      title: 'Balance Added',
      description: `Added ${CONSTANTS.TEST_BALANCE_ADD} TRX to your wallet (simulated)`,
    });
  }, [toast]);

  // Pay for power (3 TRX for 3-hour session)
  const payForPower = useCallback(() => {
    if (state.balance < CONSTANTS.POWER_COST) {
      toast({
        variant: 'destructive',
        title: 'Insufficient Balance',
        description: `You need ${CONSTANTS.POWER_COST} TRX to activate the miner.`,
      });
      return;
    }

    const now = Date.now();
    setState(prev => ({
      ...prev,
      balance: prev.balance - CONSTANTS.POWER_COST,
      hasPaidForPower: true,
      isAirFlowActive: false, // Reset Air Flow for new session
      totalSessionDuration: CONSTANTS.BASE_SESSION_DURATION,
      currentTemperature: CONSTANTS.MIN_TEMPERATURE,
      sessionStartTime: now,
      lastUpdateTime: now,
    }));

    toast({
      title: 'Payment Successful',
      description: 'Miner activated for 3 hours. You can now start mining!',
    });
    setPaymentOpen(false);
  }, [state.balance, toast]);

  // Pay for Air Flow (1 TRX to extend session and boost mining)
  const payForAirFlow = useCallback(() => {
    if (state.balance < CONSTANTS.AIRFLOW_COST) {
      toast({
        variant: 'destructive',
        title: 'Insufficient Balance',
        description: `You need ${CONSTANTS.AIRFLOW_COST} TRX for Air Flow upgrade.`,
      });
      return;
    }

    if (!state.hasPaidForPower) {
      toast({
        variant: 'destructive',
        title: 'Power Required',
        description: 'You must activate the miner first (3 TRX) before purchasing Air Flow.',
      });
      return;
    }

    const now = Date.now();
    const elapsed = state.sessionStartTime ? now - state.sessionStartTime : 0;
    const remainingFromBase = CONSTANTS.BASE_SESSION_DURATION - elapsed;
    const newTotalDuration = state.isAirFlowActive 
      ? state.totalSessionDuration 
      : CONSTANTS.AIRFLOW_SESSION_DURATION;

    setState(prev => ({
      ...prev,
      balance: prev.balance - CONSTANTS.AIRFLOW_COST,
      isAirFlowActive: true,
      totalSessionDuration: newTotalDuration,
      lastUpdateTime: now,
    }));

    toast({
      title: 'Air Flow Activated!',
      description: 'Mining rate tripled and session extended to 6 hours!',
    });
    setPaymentOpen(false);
  }, [state.balance, state.hasPaidForPower, state.isAirFlowActive, state.sessionStartTime, state.totalSessionDuration, toast]);

  // Toggle power on/off
  const togglePower = useCallback(() => {
    if (!state.hasPaidForPower) {
      toast({
        variant: 'destructive',
        title: 'Payment Required',
        description: 'You must pay 3 TRX to activate the miner.',
      });
      setPaymentOpen(true);
      return;
    }

    const now = Date.now();
    if (!state.isPowerOn) {
      // Starting power
      setState(prev => ({
        ...prev,
        isPowerOn: true,
        sessionStartTime: prev.sessionStartTime || now,
        lastUpdateTime: now,
      }));
    } else {
      // Stopping power (pauses mining)
      setState(prev => ({
        ...prev,
        isPowerOn: false,
        lastUpdateTime: now,
      }));
    }
  }, [state.hasPaidForPower, state.isPowerOn, toast]);

  // Get temperature color
  const tempState = getTemperatureState(state.currentTemperature);
  const tempColor = tempState === 'green' 
    ? 'text-[hsl(var(--temp-green))]' 
    : tempState === 'yellow' 
    ? 'text-[hsl(var(--temp-yellow))]' 
    : 'text-[hsl(var(--temp-red))]';

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center p-4 md:p-8">
      {/* Main Content */}
      <div className="w-full max-w-md flex flex-col items-center gap-8">
        
        {/* Fan Icon */}
        <div className="relative">
          <img
            src={fanImage}
            alt="Mining Fan"
            className={`w-48 h-48 md:w-64 md:h-64 transition-all ${
              !state.isPowerOn ? '' : state.isAirFlowActive ? 'animate-spin-fast animate-pulse-glow-strong' : 'animate-spin-slow'
            }`}
            style={{
              filter: state.isPowerOn && state.isAirFlowActive 
                ? 'drop-shadow(0 0 20px hsl(var(--airflow-blue))) drop-shadow(0 0 40px hsl(var(--airflow-blue)))' 
                : state.isPowerOn 
                ? 'drop-shadow(0 0 12px hsl(var(--accent))) drop-shadow(0 0 24px hsl(var(--accent)))' 
                : 'none',
              animationPlayState: state.isPowerOn ? 'running' : 'paused',
            }}
            data-testid="img-fan"
          />
        </div>

        {/* Control Buttons Row */}
        <div className="w-full flex items-center justify-center gap-4">
          {/* Air Flow Button (Square, Left) */}
          <Button
            size="icon"
            variant={state.isAirFlowActive ? 'default' : 'outline'}
            onClick={() => setPaymentOpen(true)}
            disabled={!state.hasPaidForPower}
            className={`h-16 w-16 ${
              state.isAirFlowActive 
                ? 'bg-[hsl(var(--airflow-blue))] hover:bg-[hsl(var(--airflow-blue))] border-[hsl(var(--airflow-blue))]' 
                : ''
            }`}
            style={{
              boxShadow: state.isAirFlowActive 
                ? '0 0 16px hsl(var(--airflow-blue)), 0 0 32px hsl(var(--airflow-blue))' 
                : undefined,
            }}
            data-testid="button-airflow"
          >
            <Wind className="h-8 w-8" />
          </Button>

          {/* Power Button (Rectangular, Large) */}
          <Button
            size="lg"
            onClick={togglePower}
            disabled={!state.hasPaidForPower}
            className={`h-16 px-12 text-lg font-bold ${
              state.isPowerOn 
                ? 'bg-[hsl(var(--accent))] hover:bg-[hsl(var(--accent))] text-[hsl(var(--accent-foreground))] border-[hsl(var(--accent))]' 
                : ''
            }`}
            style={{
              boxShadow: state.isPowerOn 
                ? '0 0 16px hsl(var(--accent)), 0 0 32px hsl(var(--accent))' 
                : undefined,
            }}
            data-testid="button-power"
          >
            <Power className="h-6 w-6 mr-2" />
            {state.isPowerOn ? 'ON' : 'OFF'}
          </Button>
        </div>

        {/* Temperature Display */}
        <Button
          variant="outline"
          size="lg"
          className={`w-full h-14 text-lg font-mono pointer-events-none ${tempColor}`}
          style={{
            borderColor: `hsl(var(--temp-${tempState}))`,
            boxShadow: `0 0 12px hsl(var(--temp-${tempState}))`,
          }}
          data-testid="display-temperature"
        >
          <Thermometer className="h-5 w-5 mr-2" />
          TEMP: {Math.round(state.currentTemperature)}°C
        </Button>

        {/* Timer Display (shown when mining) */}
        {state.isPowerOn && (
          <div className="text-center space-y-1">
            <p className="text-sm text-muted-foreground">Time Remaining</p>
            <p className="text-3xl font-mono font-bold text-primary" data-testid="text-timer">
              {timeRemaining}
            </p>
          </div>
        )}

        {/* Mined TRX Counter */}
        <Card className="w-full p-6 text-center bg-card/50 backdrop-blur-sm border-primary/30">
          <p className="text-sm text-muted-foreground mb-2">Mined TRX</p>
          <p className="text-4xl font-bold font-mono text-primary" data-testid="text-mined">
            {state.minedTRX.toFixed(4)}
          </p>
        </Card>

        {/* Bottom Navigation */}
        <div className="fixed bottom-0 left-0 right-0 bg-card/80 backdrop-blur-md border-t border-border">
          <div className="max-w-md mx-auto px-8 py-4 flex items-center justify-around">
            <button
              onClick={() => {}}
              className="flex flex-col items-center gap-1 text-muted-foreground hover:text-primary transition-colors"
              data-testid="button-nav-status"
            >
              <Fan className="h-6 w-6" />
              <span className="text-xs">Status</span>
            </button>

            <button
              onClick={() => setWalletOpen(true)}
              className="flex flex-col items-center gap-1 text-muted-foreground hover:text-primary transition-colors"
              data-testid="button-nav-wallet"
            >
              <Wallet className="h-6 w-6" />
              <span className="text-xs">Wallet</span>
            </button>

            <button
              onClick={() => setPaymentOpen(true)}
              className="flex flex-col items-center gap-1 text-muted-foreground hover:text-primary transition-colors"
              data-testid="button-nav-payment"
            >
              <CreditCard className="h-6 w-6" />
              <span className="text-xs">Payment</span>
            </button>
          </div>
        </div>
      </div>

      {/* Wallet Modal */}
      <Dialog open={walletOpen} onOpenChange={setWalletOpen}>
        <DialogContent className="sm:max-w-md" data-testid="modal-wallet">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Wallet className="h-5 w-5 text-primary" />
              Wallet
            </DialogTitle>
            <DialogDescription>
              Manage your TRX balance (simulated)
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-6 py-4">
            <Card className="p-6 text-center bg-primary/10 border-primary/30">
              <p className="text-sm text-muted-foreground mb-2">Current Balance</p>
              <p className="text-4xl font-bold font-mono text-primary" data-testid="text-balance">
                {state.balance.toFixed(4)} TRX
              </p>
            </Card>
            
            <Button
              onClick={addTestBalance}
              className="w-full"
              size="lg"
              data-testid="button-add-balance"
            >
              + Add {CONSTANTS.TEST_BALANCE_ADD} TRX (Test)
            </Button>

            <div className="text-xs text-muted-foreground text-center space-y-1">
              <p>Mined: {state.minedTRX.toFixed(4)} TRX</p>
              <p className="text-xs opacity-50">All transactions are simulated</p>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Payment Modal */}
      <Dialog open={paymentOpen} onOpenChange={setPaymentOpen}>
        <DialogContent className="sm:max-w-md" data-testid="modal-payment">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <CreditCard className="h-5 w-5 text-primary" />
              Activate Features
            </DialogTitle>
            <DialogDescription>
              Pay TRX to unlock mining features
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <Card className="p-4 bg-card/50">
              <p className="text-sm text-muted-foreground mb-1">Your Balance</p>
              <p className="text-2xl font-bold text-primary">{state.balance.toFixed(2)} TRX</p>
            </Card>

            {/* Power Activation */}
            <div className="space-y-2">
              <Button
                onClick={payForPower}
                className="w-full"
                size="lg"
                variant={state.hasPaidForPower ? 'outline' : 'default'}
                data-testid="button-pay-power"
              >
                <Power className="h-5 w-5 mr-2" />
                {state.hasPaidForPower ? `Start New Session (${CONSTANTS.POWER_COST} TRX)` : `Activate Power (${CONSTANTS.POWER_COST} TRX)`}
              </Button>
              <p className="text-xs text-muted-foreground">
                {state.hasPaidForPower ? 'Resets current session and starts fresh' : 'Enables 3-hour mining session • 1 TRX/hour'}
              </p>
            </div>

            {/* Air Flow Upgrade */}
            <div className="space-y-2">
              <Button
                onClick={payForAirFlow}
                disabled={!state.hasPaidForPower || state.isAirFlowActive}
                className="w-full bg-[hsl(var(--airflow-blue))] hover:bg-[hsl(var(--airflow-blue))] border-[hsl(var(--airflow-blue))]"
                size="lg"
                variant={state.isAirFlowActive ? 'outline' : 'default'}
                data-testid="button-pay-airflow"
              >
                <Wind className="h-5 w-5 mr-2" />
                {state.isAirFlowActive ? 'Air Flow Active ✓' : `Activate Air Flow (${CONSTANTS.AIRFLOW_COST} TRX)`}
              </Button>
              <p className="text-xs text-muted-foreground">
                Extends to 6 hours • Triples mining rate to 3 TRX/hour
              </p>
            </div>

            <p className="text-xs text-muted-foreground text-center opacity-50 pt-2">
              All payments are simulated (no blockchain)
            </p>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
